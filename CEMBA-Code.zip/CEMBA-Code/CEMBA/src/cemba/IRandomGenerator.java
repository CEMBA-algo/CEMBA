package cemba;
/**
 *
 * @author CEMBA
 */
public interface IRandomGenerator {

    public int nextInt(int upperLimit);

    public double nextDouble();
}
