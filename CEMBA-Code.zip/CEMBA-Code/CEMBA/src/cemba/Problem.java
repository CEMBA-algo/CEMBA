/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cemba;

/**
 *
 * @author CEMBA
 */
public abstract class Problem {
    
    /**
     * Stores the number of variables of the upper level problem
     */
    private int numberOfVariables;
    private int numberOfVariablesL;
    private int[] lowerLimitL_;
    private int[] upperLimitL_;
    /**
     * Stores the upper bound values for each variable
     * (only if needed)
     */
    private int[] upperLimit_;

    /**
     * Stores the lower bound values for each variable
     * (only if needed)
     */
    private int[] lowerLimit_;
    
    public Problem() {
    }

    public Problem(int numberOfVariables, int[] upperLimit_, int[] lowerLimit_) {
        this.numberOfVariables = numberOfVariables;
        this.upperLimit_ = upperLimit_;
        this.lowerLimit_ = lowerLimit_;
    }

    public int[] getUpperLimit() {
        return upperLimit_;
    }
    
    public int getUpperLimit(int index) {
        return upperLimit_[index];
    }

    public void setUpperLimit(int[] upperLimit_) {
        this.upperLimit_ = upperLimit_;
    }

    public int[] getLowerLimit() {
        return lowerLimit_;
    }
    
    public int getLowerLimit(int index) {
        return lowerLimit_[index];
    }

    public void setLowerLimit(int[] lowerLimit_) {
        this.lowerLimit_ = lowerLimit_;
    }

    public int getNumberOfVariables() {
        return numberOfVariables;
    }

    public void setNumberOfVariables(int numberOfVariables) {
        this.numberOfVariables = numberOfVariables;
    }
    
    //public void evaluateLowerLevel(Solution upperSolution, Solution lowerSolution) {
       // evaluateConstraints(upperSolution);
      //  double fitness = 0.0;
      //  for (int i = 0; i < upperSolution.getNumberOfDecisionVariables(); i++) {
       //     fitness += (lowerSolution.getVariable(i) + upperSolution.getVariable(i)) ;
       // }
       // upperSolution.setFitness(fitness);
    //}
    public void evaluateLowerLevel(Solution upperSolution, Solution lowerSolution) {
       // evaluateConstraints(upperSolution);
        double fitness = 0.0;
        for (int i = 0; i < lowerSolution.getNumberOfDecisionVariables(); i++) {
            fitness += (lowerSolution.getVariable(i) + upperSolution.getVariable(i));
        }
        upperSolution.setFitness(fitness);
    }
    public int getNumberOfVariablesLowerLevel() {
        return numberOfVariablesL;
    }
    public int getLowerLimitLowerLevel(int index) {
        return lowerLimitL_[index];
    }
    public int getUpperLimitLowerLevel(int index) {
        return upperLimitL_[index];
    }
    public void setLowerLimitLowerLevel(int[] lowerLimit_) {
        this.lowerLimitL_ = lowerLimit_;
    }
    public void setUpperLimitLowerLevel(int[] upperLimit_) {
        this.upperLimitL_ = upperLimit_;
    }
    public void setNumberOfVariablesUpperLevel(int numberOfVariables) {
        this.numberOfVariables = numberOfVariables;
    }

    public void setNumberOfVariablesLowerLevel(int numberOfVariables) {
        this.numberOfVariablesL = numberOfVariables;
    }
     /**
     * Evaluates a upper level <code>Solution</code> object.
     *
     * @param upperSolution The <code>Upper Level Solution</code> to evaluate.
     * @param lowerSolution The <code>Lower Level Solution</code> to evaluate.
     */
    public abstract void evaluate(Solution upperSolution, Solution lowerSolution);

    /**
     * Evaluates the overall constraint violation of a <code>Solution</code>
     * object.
     *
     * @param solution The <code>Solution</code> to evaluate.
     */
    public abstract void evaluateConstraints(Solution solution);

    /**
     * Evaluates a lower level <code>Solution</code> object.
     *
     * @param upperSolution The <code>Upper Level Solution</code> to evaluate.
     * @param lowerSolution The <code>Lower Level Solution</code> to evaluate.
     */
//    public abstract void evaluateLowerLevel(Solution upperSolution, Solution lowerSolution);

    /**
     * Evaluates the overall constraint violation of a <code>Solution</code>
     * object.
     *
     * @param solution The <code>Solution</code> to evaluate.
     */
    public abstract void evaluateLowerLevelConstraints(Solution solution);

    public void setNumberOfVariablesUpperLevel(int[] numberofplants) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setNumberOfVariablesLowerLevel(int[] numberofplants) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
