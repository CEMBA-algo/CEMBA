/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cemba;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author CEMBA
 */
public class Solution {
    
    /**
     * Stores the problem
     */
    private Problem problem_;

    /**
     * Stores the decision variables of the solution.
     */
    private int[] variable_;

    /**
     * Stores the so called fitness value.
     */
    private double fitness_;
    
    public Solution() {
        variable_ = null;
        fitness_ = 0.0;
    }

    public Solution(Problem problem) {
        this.problem_ = problem;
        variable_ = new int[problem.getNumberOfVariables()];
        for (int i = 0; i < problem.getNumberOfVariables(); i++) {
            variable_[i] = this.problem_.getLowerLimit(i) + new Random().nextInt(this.problem_.getUpperLimit(i) - this.problem_.getLowerLimit(i));
        }
        fitness_ = 0.0;
    }
    
    
    
    public Solution(Solution solution) {
        this.problem_ = solution.getProblem();
       System.arraycopy(solution.getVariable(), 0, variable_, 0, solution.getVariable().length);
        fitness_ = solution.getFitness();
    }
    

    //Solution(Problem problem, String lower) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}
    public Solution(Problem problem, String level) {
        this.problem_ = problem;
        if(level.equals("upper")) {
            variable_ = new int[problem.getNumberOfVariables()];
            for (int i = 0; i < problem.getNumberOfVariables(); i++) {
                variable_[i] = PseudoRandom.randInt(this.problem_.getLowerLimit(i), this.problem_.getUpperLimit(i));
            }
        } else if (level.equals("lower")) {
            variable_ = new int[problem.getNumberOfVariablesLowerLevel()];
            for (int i = 0; i < problem.getNumberOfVariablesLowerLevel(); i++) {
                variable_[i] = PseudoRandom.randInt(this.problem_.getLowerLimitLowerLevel(i), this.problem_.getUpperLimitLowerLevel(i));
            }
        }
        fitness_ = 0.0;
    }

    public int[] getVariable() {
        return variable_;
    }
    
    public int getVariable(int index) {
        return variable_[index];
    }
    
    public int getNumberOfDecisionVariables() {
        return variable_.length;
    }

    public int[] getLowerBound() {
        return this.problem_.getLowerLimit();
    }
    
    public int getLowerBound(int index) {
        return this.problem_.getLowerLimit(index);
    }

    public void setLowerBound(int[] lowerBound_) {
        this.problem_.setLowerLimit(lowerBound_);
    }

    public int[] getUpperBound() {
        return this.problem_.getUpperLimit();
    }
    
    public int getUpperBound(int index) {
        return this.problem_.getUpperLimit(index);
    }

    public void setUpperBound(int[] upperBound_) {
        this.problem_.setUpperLimit(upperBound_);
    }

    public void setVariable(int[] variable_) {
        this.variable_ = variable_;
        
    }

    public double getFitness() {
        return fitness_;
    }

    public void setFitness(double fitness_) {
        this.fitness_ = fitness_;
    }

    public Problem getProblem() {
        return problem_;
    }

    public void setProblem(Problem problem_) {
        this.problem_ = problem_;
    }  
    
    public double calculateSpacing(int index, int p) {
        return (double) getUpperBound(index) / p;
    }
    
    public boolean isLowerUpperBound(int value, int index) {
        return value < getUpperBound(index);
    }
    
    public int closet(int value, double spacing, int index) {
        double get = (int) value + spacing;
        ArrayList<Integer> arrayArray = new ArrayList<>();
        for (int i = getLowerBound(index); i <= getUpperBound(index); i++) {
            arrayArray.add(i);
        }
        int[] intArray = new int[arrayArray.size()];
        for (int i = 0; i < intArray.length; i++) {
            intArray[i] = arrayArray.get(i);
        }
        int rank = rank(get, intArray);
        if (rank > intArray.length - 1) {
            return intArray[intArray.length - 1];
        } else if (rank == 0) {
            return intArray[0];
        } else if (get == intArray[rank]) {
            return intArray[rank];
        } else {
            double diff1 = Math.abs(intArray[rank] - get);
            double diff2 = Math.abs(intArray[rank - 1] - get);
            if (diff1 < diff2) {
                return intArray[rank];
            } else if (diff1 > diff2) {
                return intArray[rank - 1];
            } else {
                if (new Random().nextBoolean()) {
                    return intArray[rank];
                } else {
                    return intArray[rank - 1];
                }
            }
        }
    }
    
    public int rank(double key, int[] a) {
        int lo = 0;
        int hi = a.length - 1;
        int mid = lo + (hi - lo) / 2;
        while (lo <= hi) {
            // Key is in a[lo..hi] or not present.
            if (key < a[mid]) {
                hi = mid - 1;
            } else if (key > a[mid]) {
                lo = mid + 1;
            } else {
                return mid;
            }
            mid = lo + (hi - lo) / 2;
        }
        return mid;
    }   
    
    @Override
    public String toString() {
        String solution = "";
        for (int i = 0; i < variable_.length; i++) {
            solution = solution + variable_[i] + "\t";
        }
        return solution;
    }

    public void setVariable(int variable, int index) {
        this.variable_[index] = variable;
    }

    
}
