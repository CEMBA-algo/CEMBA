/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cemba;

/**
 *
 * @author CEMBA
 */
public class CEMBA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     
        int populationSize = 100;
       int UPopulationSize = 100;
        
        int maxFE = 2000;
        int UMaxFE = 2000;
        
        double mutationProbability = 0.1;
        double UMutationProbability = 0.1;
         
        int[] lowerBound = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        int[] upperBound = {9, 9, 9, 9, 9, 9, 9, 9, 9, 9};
        
        int numberOfDecisionVariables = 10;
        int p= 3;
       Problem problem = new Problem(numberOfDecisionVariables, upperBound, lowerBound) {
         @Override
         public void evaluate(Solution upperSolution, Solution lowerSolution) {
             throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
           }

           @Override
           public void evaluateConstraints(Solution solution) {
             throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
           }

          @Override
           public void evaluateLowerLevelConstraints(Solution solution) {
              throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
           }
       };  
     // UpperLevel1 algorithm = new UpperLevel1 (problem, UpperpopulationSize, XL, maxFE,mutationProbability);
      
        
        
       //Lower algorithm = new Lower (problem, populationSize, maxFE, mutationProbability, UPopulationSize, UMaxFE, UMutationProbability);
       Lower algorithm = new Lower (problem, populationSize, maxFE, mutationProbability, UPopulationSize, UMaxFE, UMutationProbability);
        System.out.println("Running the CEMBA...");
        Solution result = algorithm.execute().get(0);
        System.out.println("Lower Soltion ==>");
        System.out.println(result.toString());
        System.out.println("Upper Soltion ==>");
        System.out.println(algorithm.getUpperrSolution().toString());
        System.out.println("Upper FE ==> "+algorithm.getUpperFE());
        System.out.println("Lower FE ==> "+algorithm.getLowerFE());
        System.out.println("The CEMBA end");
}
    }
    

