/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cemba;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author CEMBA
 */
public class SolutionSet {
    
    private int variable_;
    /**
     * Stores a list of <code>solution</code> objects.
     */
    protected final List<Solution> solutionsList_;

    /**
     * Constructor. Creates an unbounded solution set.
     */
    public SolutionSet() {
        solutionsList_ = new ArrayList<>();
    } // SolutionSet

    public SolutionSet(SolutionSet solutionSet) {
        solutionsList_ = new ArrayList<>();
        for (int i = 0; i < solutionSet.size(); i++) {
            solutionsList_.add(new Solution(solutionSet.get(i)));
        }
    } // SolutionSet

    /**
     * Inserts a new solution into the SolutionSet.
     *
     * @param solution The <code>Solution</code> to store
     * @return True If the <code>Solution</code> has been inserted, false
     * otherwise.
     */
    public boolean add(Solution solution) {
        solutionsList_.add(solution);
        return true;
    } // add

    public boolean add(int index, Solution solution) {
        solutionsList_.add(index, solution);
        return true;
    }

    public boolean add(SolutionSet solutionSet) {
        for (int i = 0; i < solutionSet.size(); i++) {
            solutionsList_.add(solutionSet.get(i));
        }
        return true;
    }

    /*
     public void add(Solution solution) {
     if (solutionsList_.size() == capacity_)
     try {
     throw new JMException("SolutionSet.Add(): the population is full") ;
     } catch (JMException e) {
     e.printStackTrace();
     }
     else
     solutionsList_.add(solution);
     }
     */

    /**
     * Returns the ith solution in the set.
     *
     * @param i Position of the solution to obtain.
     * @return The <code>Solution</code> at the position i.
     * @throws IndexOutOfBoundsException Exception
     */
    public Solution get(int i) {
        if (i >= solutionsList_.size()) {
            throw new IndexOutOfBoundsException("Index out of Bound " + i);

        }

        return solutionsList_.get(i);
    } // get

    /**
     * Sorts a SolutionSet using a <code>Comparator</code>.
     *
     * @param comparator <code>Comparator</code> used to sort.
     */
    public void sort(Comparator comparator) {
        if (comparator == null) {
            System.err.println("No criterium for comparing exist");
            return;
        } // if
        Collections.sort(solutionsList_, comparator);
    } // sort

    /**
     * Returns the index of the best Solution using a <code>Comparator</code>.
     * If there are more than one occurrences, only the index of the first one
     * is returned
     *
     * @param comparator <code>Comparator</code> used to compare solutions.
     * @return The index of the best Solution attending to the comparator or      <code>-1<code> if the SolutionSet is empty
     */
    public int indexBest(Comparator comparator) {
        if ((solutionsList_ == null) || (this.solutionsList_.isEmpty())) {
            return -1;
        }

        int index = 0;
        Solution bestKnown = solutionsList_.get(0), candidateSolution;
        int flag;
        for (int i = 1; i < solutionsList_.size(); i++) {
            candidateSolution = solutionsList_.get(i);
            flag = comparator.compare(bestKnown, candidateSolution);
            if (flag == +1) {
                index = i;
                bestKnown = candidateSolution;
            }
        }

        return index;
    } // indexBest

    /**
     * Returns the best Solution using a <code>Comparator</code>. If there are
     * more than one occurrences, only the first one is returned
     *
     * @param comparator <code>Comparator</code> used to compare solutions.
     * @return The best Solution attending to the comparator or <code>null<code>
     * if the SolutionSet is empty
     */
    public Solution best(Comparator comparator) {
        int indexBest = indexBest(comparator);
        if (indexBest < 0) {
            return null;
        } else {
            return solutionsList_.get(indexBest);
        }

    } // best  

    /**
     * Returns the index of the worst Solution using a <code>Comparator</code>.
     * If there are more than one occurrences, only the index of the first one
     * is returned
     *
     * @param comparator <code>Comparator</code> used to compare solutions.
     * @return The index of the worst Solution attending to the comparator or      <code>-1<code> if the SolutionSet is empty
     */
    public int indexWorst(Comparator comparator) {
        if ((solutionsList_ == null) || (this.solutionsList_.isEmpty())) {
            return -1;
        }

        int index = 0;
        Solution worstKnown = solutionsList_.get(0), candidateSolution;
        int flag;
        for (int i = 1; i < solutionsList_.size(); i++) {
            candidateSolution = solutionsList_.get(i);
            flag = comparator.compare(worstKnown, candidateSolution);
            if (flag == -1) {
                index = i;
                worstKnown = candidateSolution;
            }
        }

        return index;

    } // indexWorst

    /**
     * Returns the worst Solution using a <code>Comparator</code>. If there are
     * more than one occurrences, only the first one is returned
     *
     * @param comparator <code>Comparator</code> used to compare solutions.
     * @return The worst Solution attending to the comparator or <code>null<code>
     * if the SolutionSet is empty
     */
    public Solution worst(Comparator comparator) {

        int index = indexWorst(comparator);
        if (index < 0) {
            return null;
        } else {
            return solutionsList_.get(index);
        }

    } // worst

    /**
     * Returns the number of solutions in the SolutionSet.
     *
     * @return The size of the SolutionSet.
     */
    public int size() {
        return solutionsList_.size();
    } // size

    public boolean isEmpty() {
        return this.solutionsList_.isEmpty();
    }

    /**
     * Empties the SolutionSet
     */
    public void clear() {
        solutionsList_.clear();
    } // clear

    /**
     * Deletes the <code>Solution</code> at position i in the set.
     *
     * @param i The position of the solution to remove.
     */
    public void remove(int i) {
        if (i > solutionsList_.size() - 1) {
            System.err.println("Size is: " + this.size());
        } // if
        solutionsList_.remove(i);
    } // remove

    /**
     * Returns an <code>Iterator</code> to access to the solution set list.
     *
     * @return the <code>Iterator</code>.
     */
    public Iterator<Solution> iterator() {
        return solutionsList_.iterator();
    } // iterator   

    /**
     * Returns a new <code>SolutionSet</code> which is the result of the union
     * between the current solution set and the one passed as a parameter.
     *
     * @param solutionSet SolutionSet to join with the current solutionSet.
     * @return The result of the union operation.
     */
    public SolutionSet union(SolutionSet solutionSet) {
        //Check the correct size. In development
        int newSize = this.size() + solutionSet.size();

        //Create a new population 
        SolutionSet union = new SolutionSet();
        for (int i = 0; i < this.size(); i++) {
            union.add(new Solution(this.get(i)));
        } // for

        for (int i = this.size(); i < (this.size() + solutionSet.size()); i++) {
            union.add(new Solution(solutionSet.get(i - this.size())));
        } // for

        return union;
    } // union                   

    /**
     * Replaces a solution by a new one
     *
     * @param position The position of the solution to replace
     * @param solution The new solution
     */
    public void replace(int position, Solution solution) {
        if (position > this.solutionsList_.size()) {
            solutionsList_.add(solution);
        } // if 
        solutionsList_.remove(position);
        solutionsList_.add(position, solution);
    } // replace

    /**
     * Convert a solution to string
     */
    @Override
    public String toString() {
        String solutionSet = "";
        for (int i = 0; i < solutionsList_.size(); i++) {
            solutionSet = solutionSet + solutionsList_.get(i).toString() + "\n";
        }
        return solutionSet;
    }
    public int getVariable(int c) {
        return variable_;
    }// replace
    
}
