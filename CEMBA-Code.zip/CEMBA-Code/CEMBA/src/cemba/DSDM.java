package cemba;
/**
 *
 * @author CEMBA
 */
import java.util.ArrayList;
import java.util.Comparator;


public class DSDM {

    private SolutionSet referencePoints;
    private Problem problem;
private int[] variable_;
    public DSDM(Problem problem, int p) throws Exception {
        this.problem = problem;
        ArrayList<ArrayList> ranges = new ArrayList();
        int maxSizeRange = 0, mini;
        double spacing;
        Solution solution = new Solution(this.problem);
        int decisionVariablesNum = solution.getNumberOfDecisionVariables();
        for (int i = 0; i < decisionVariablesNum; i++) {
            spacing = solution.calculateSpacing(i, p);
            // rangei contains coordinates of the decision variable i
            ArrayList<Integer> rangei = new ArrayList();
            mini = solution.getLowerBound(i);
            rangei.add(mini);
            while (solution.isLowerUpperBound(rangei.get(rangei.size() - 1), i)) {
                //returns the coordinates of the decision variable i 
                int r = solution.closet(rangei.get(rangei.size() - 1), spacing, i);
                if (!isInTheRanges(r, rangei)) {
                    rangei.add(r);
                }
            }
            if (maxSizeRange < rangei.size()) {
                maxSizeRange = rangei.size();
            }
            ranges.add(rangei);
        }
        referencePoints = combinaison(ranges, maxSizeRange);
    }

   //DSDM() {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   //}

    private SolutionSet combinaison(ArrayList<ArrayList> ranges, int maxSizeRange) {
        int index = maxSizeRange;
        int[] compteurs = new int[ranges.size()];
        for (int i = 0; i < compteurs.length; i++) {
            compteurs[i] = 0;
        }
        SolutionSet refPts = new SolutionSet();
        while (index >= 1) {
            for (int i = 1; i < compteurs.length; i++) {
                compteurs[i] = 0;
            }
            for (int i = 0; i < index; i++) {
                int[] decisionVars = new int[ranges.size()];
                decisionVars[0] = (int) ranges.get(0).get(compteurs[0]);
                for (int j = 1; j < ranges.size(); j++) {
                    if (compteurs[j] >= ranges.get(j).size()) {
                        compteurs[j] = 0;
                    }
                    decisionVars[j] = (int) ranges.get(j).get(compteurs[j]++);
                }
                Solution newPtRef = new Solution(problem);
                newPtRef.setVariable(decisionVars);
                refPts.add(newPtRef);
            }
            index--;
            compteurs[0]++;
            if (compteurs[0] >= ranges.get(0).size()) {
                compteurs[0] = 0;
            }
        }
        return refPts;
    }

    private boolean isInTheRanges(int value, ArrayList<Integer> ranges) {
        boolean found = false;
        int i = 0;
        while (!found && i < ranges.size()) {
            if (ranges.get(i) == value) {
                found = true;
            } else {
                i++;
            }
        }
        return found;
    }

    public SolutionSet getReferencePoints() {
        return referencePoints;
    }
     public int size() {
        return referencePoints.size();
    } 
     public Solution get(int i) {
        if (i >= referencePoints.size()) {
            throw new IndexOutOfBoundsException("Index out of Bound " + i);

        }

        return referencePoints.get(i);
    } 
   public Solution best(Comparator comparator) {
        int indexBest = indexBest(comparator);
        if (indexBest < 0) {
            return null;
        } else {
            return referencePoints.get(indexBest);
        }

    }
   public int indexBest(Comparator comparator) {
        if ((referencePoints == null) || (this.referencePoints.isEmpty())) {
            return -1;
        }

        int index = 0;
        Solution bestKnown = referencePoints.get(0), candidateSolution;
        int flag;
        for (int i = 1; i < referencePoints.size(); i++) {
            candidateSolution = referencePoints.get(i);
            flag = comparator.compare(bestKnown, candidateSolution);
            if (flag == +1) {
                index = i;
                bestKnown = candidateSolution;
            }
        }

        return index;
    } 
   public int[] getVariable() {
        return variable_;
    }
}

