/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cemba;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

/**
 *
 * @author CEMBA
 */
public class Lower {
    
     private SolutionSet referencePoints;
      private SolutionSet referencePoints1;
    private Solution bestSolution;
    private Solution bestSolution1;
   // private Solution UpperSolution;
    Solution UpperrSolution ;
    private Problem problem;
    private int popSize;
    private int maxFE;
    private double mutationProbability;
    private int LFE = 0;
    private int UFE = 0;
    private int p =3;
   // private int XU;
    private int UpopSize;
    private int UmaxFE;
    private double UmutationProbability;
    
   
  //  Vector vect =new Vector();
    
    
    public Lower(Problem problem,  int popSize,  int maxFE, double mutationProbability, int UPopSize, int UMaxFE, double UMutationProbability) {
        this.problem = problem;
        this.popSize = popSize;
        this.maxFE = maxFE;
        this.mutationProbability = mutationProbability;
         this.UpopSize = UPopSize;
        this.UmaxFE = UMaxFE;
        this.UmutationProbability = UMutationProbability;
       
    }
    SolutionSet result = new SolutionSet();
    SolutionSet bestS = new SolutionSet();
    public SolutionSet execute(){
       // SolutionSet result = new SolutionSet();
       bestSolution = new Solution(problem, "lower");
        bestSolution.setFitness(Double.NEGATIVE_INFINITY);
      // Population lower 1:  DSDM
        //this.problem = problem;
        ArrayList<ArrayList> ranges = new ArrayList();
        int maxSizeRange = 0, mini;
        double spacing;
        Solution solution = new Solution(this.problem);
        int decisionVariablesNum = solution.getNumberOfDecisionVariables();
        for (int i = 0; i < decisionVariablesNum; i++) {
            spacing = solution.calculateSpacing(i, p);
            // rangei contains coordinates of the decision variable i
            ArrayList<Integer> rangei = new ArrayList();
            mini = solution.getLowerBound(i);
            rangei.add(mini);
            while (solution.isLowerUpperBound(rangei.get(rangei.size() - 1), i)) {
                //returns the coordinates of the decision variable i 
                int r = solution.closet(rangei.get(rangei.size() - 1), spacing, i);
                if (!isInTheRanges(r, rangei)) {
                    rangei.add(r);
                }
            }
            if (maxSizeRange < rangei.size()) {
                maxSizeRange = rangei.size();
            }
            ranges.add(rangei);
        }
             referencePoints = combinaison(ranges, maxSizeRange);
             
        evaluatePopulation(referencePoints);
        result.add(bestSolution);
        // Population lower 2:  DSDM
        //this.problem = problem;
        ArrayList<ArrayList> ranges1 = new ArrayList();
        int maxSizeRange1 = 0, mini1;
        double spacing1;
        Solution solution1 = new Solution(this.problem);
        int decisionVariablesNum1 = solution.getNumberOfDecisionVariables();
        for (int i = 0; i < decisionVariablesNum1; i++) {
            spacing1 = solution1.calculateSpacing(i, p);
            // rangei contains coordinates of the decision variable i
            ArrayList<Integer> rangei = new ArrayList();
            mini1 = solution1.getLowerBound(i);
            rangei.add(mini1);
            while (solution1.isLowerUpperBound(rangei.get(rangei.size() - 1), i)) {
                //returns the coordinates of the decision variable i 
                int r = solution1.closet(rangei.get(rangei.size() - 1), spacing1, i);
                if (!isInTheRanges(r, rangei)) {
                    rangei.add(r);
                }
            }
            if (maxSizeRange < rangei.size()) {
                maxSizeRange = rangei.size();
            }
            ranges.add(rangei);
        }
             referencePoints1 = combinaison(ranges, maxSizeRange);
             
        evaluatePopulation(referencePoints1);
        result.add(bestSolution1);
        
        //Cycle lower population 1
        SolutionSet referencePoints = new SolutionSet();
        SolutionSet population = new SolutionSet(referencePoints);
        int generation = 0;
        while (generation < 20) {
            generation++;
            SolutionSet Parents = new SolutionSet(population);
            SolutionSet offsprings = new SolutionSet();
            int i = 0;
            while (i < (population.size() / 2)) {
                // SELECTION
                int index1 = PseudoRandom.randInt(0, Parents.size() - 1), index2 = index1, index3 = index1, index4 = index1;
                while (index2 == index1) {
                    index2 = PseudoRandom.randInt(0, Parents.size() - 1);
                }
                while (index3 == index1 || index3 == index2) {
                    index3 = PseudoRandom.randInt(0, Parents.size() - 1);
                }
                while (index4 == index1 || index4 == index2 || index4 == index3) {
                    index4 = PseudoRandom.randInt(0, Parents.size() - 1);
                }
                Solution parent1 = Parents.get(index1);
                Solution parent2 = Parents.get(index3);
                // CROISSSEMENT
                Solution[] crossoverResult = crossoverOperator(parent1, parent2);
                // MUTATION
                for (int c = 0; c < crossoverResult.length; c++) {
                    Solution mutatedSolution = mutationOperator(crossoverResult[c]);
                    offsprings.add(mutatedSolution);
                }
                Parents.remove(index1);
                if (index3 > index1) {
                    index3--;
                }
                Parents.remove(index3);
                i += 2;
            }
            // EVALUATION
            evaluatePopulation(offsprings);
            result.add( bestSolution);
            
            // SELECTION
            population.union(offsprings);
            population.sort(new Lower.SolutionComparator());
            SolutionSet pt1 = new SolutionSet();
            for (int j = 0; j < population.size(); j++) {
                pt1.add(population.get(j));
            }
            population = new SolutionSet(pt1);
            
        }
                //Cycle lower population 2
        SolutionSet referencePoints1 = new SolutionSet();
        SolutionSet population1 = new SolutionSet(referencePoints1);
        int generation1 = 0;
        while (generation1 < 20) {
            generation1++;
            SolutionSet Parents1 = new SolutionSet(population1);
            SolutionSet offsprings1 = new SolutionSet();
            int ii = 0;
            while (ii < (population1.size() / 2)) {
                // SELECTION
                int index11 = PseudoRandom.randInt(0, Parents1.size() - 1), index21 = index11, index31 = index11, index41 = index11;
                while (index21 == index11) {
                    index21 = PseudoRandom.randInt(0, Parents1.size() - 1);
                }
                while (index31 == index11 || index31 == index21) {
                    index31 = PseudoRandom.randInt(0, Parents1.size() - 1);
                }
                while (index41 == index11 || index41 == index21 || index41 == index31) {
                    index41 = PseudoRandom.randInt(0, Parents1.size() - 1);
                }
                Solution parent11 = Parents1.get(index11);
                Solution parent21 = Parents1.get(index31);
                // CROISSSEMENT
                Solution[] crossoverResult1 = crossoverOperator(parent11, parent21);
                // MUTATION
                for (int c = 0; c < crossoverResult1.length; c++) {
                    Solution mutatedSolution = mutationOperator(crossoverResult1[c]);
                    offsprings1.add(mutatedSolution);
                }
                Parents1.remove(index11);
                if (index31 > index11) {
                    index31--;
                }
                Parents1.remove(index31);
                ii += 2;
            }
            // EVALUATION
            evaluatePopulation(offsprings1);
            result.add( bestSolution);
            
            // SELECTION
            population.union(offsprings1);
            population.sort(new Lower.SolutionComparator());
            SolutionSet pt1 = new SolutionSet();
            for (int j = 0; j < population.size(); j++) {
                pt1.add(population.get(j));
            }
            population = new SolutionSet(pt1);
           if (generation == 10) {
               if (bestSolution.getFitness()<bestSolution1.getFitness()){
                 population1.add(bestSolution);
                 population.add(bestSolution1);
               }
           }
        }
       result.add(bestSolution);
        
        
        
        
        
        return result;
         
        }
       
       
       
    
  
    
    private void evaluatePopulation(SolutionSet population){
       double fitness = 0.0;
      double fit =0.0;
        for (int i = 0; i < population.size(); i++) {
             Solution solution = population.get(i);
             Vector vect =new Vector();
             Vector vect1 =new Vector();
             
            // for (int j = 0; j < UpopSize; j++) {
           Upper UpperLevel1 = new Upper(problem, UpopSize, UmaxFE, UmutationProbability);
            UpperLevel1.addLowerSolution(population.get(i));
             // Solution UpperlevelSolution = population.get(j);
             Solution UpperlevelSolution = UpperLevel1.run().get(0);
             for (int j = 0; j < UpopSize; j++) {
          //  fitness += (solution.getVariable(i) + UpperlevelSolution.getVariable(j));    
            fitness += (solution.getFitness() + UpperlevelSolution.getFitness());  
            UpperlevelSolution.setFitness(fitness);
            bestS.add(UpperlevelSolution);
            vect.add(fitness);
        LFE++;
        UFE += UpperLevel1.getUpperFE();}
        //}}
      
        
              Collections.sort(vect);
              //System.out.println(vect);
             int N= (vect.size())/2;
           UpperrSolution = new Solution();
           bestSolution= population.get(i);
            fit = (double) vect.elementAt(N);
            if (bestSolution.getFitness() > solution.getFitness()) {
               this.bestSolution = new Solution();
               bestSolution= solution;}
            for (int s = 0; s < bestS.size(); s++){ 
             UpperrSolution = bestS.get(s);
                  if( fit == bestS.get(s).getFitness()){
                UpperrSolution = bestS.get(s);}   
            }
             }//}
     
    }
        
    
     private boolean isInTheRanges(int value, ArrayList<Integer> ranges) {
        boolean found = false;
        int i = 0;
        while (!found && i < ranges.size()) {
            if (ranges.get(i) == value) {
                found = true;
            } else {
                i++;
            }
        }
        return found;
    }
     private SolutionSet combinaison(ArrayList<ArrayList> ranges, int maxSizeRange) {
        int index = maxSizeRange;
        int[] compteurs = new int[ranges.size()];
        for (int i = 0; i < compteurs.length; i++) {
            compteurs[i] = 0;
        }
        SolutionSet refPts = new SolutionSet();
        while (index >= 1) {
            for (int i = 1; i < compteurs.length; i++) {
                compteurs[i] = 0;
            }
            for (int i = 0; i < index; i++) {
                int[] decisionVars = new int[ranges.size()];
                decisionVars[0] = (int) ranges.get(0).get(compteurs[0]);
                for (int j = 1; j < ranges.size(); j++) {
                    if (compteurs[j] >= ranges.get(j).size()) {
                        compteurs[j] = 0;
                    }
                    decisionVars[j] = (int) ranges.get(j).get(compteurs[j]++);
                }
                Solution newPtRef = new Solution(problem);
                newPtRef.setVariable(decisionVars);
                refPts.add(newPtRef);
            }
            index--;
            compteurs[0]++;
            if (compteurs[0] >= ranges.get(0).size()) {
                compteurs[0] = 0;
            }
        }
        return refPts;
    }
     public Solution[] crossoverOperator(Solution solution1, Solution solution2) {
        Solution offspring1 = new Solution(solution1);
        Solution offspring2 = new Solution(solution2);
        for (int i = 0; i < solution1.getNumberOfDecisionVariables(); i++) {
            double rand = PseudoRandom.randDouble(0, 1);
            if (rand < 0.5) {
                int var1 = solution1.getVariable(i);
                int var2 = solution2.getVariable(i);
                int aux = var1;
                var1 = var2;
                var2 = aux;
                offspring1.setVariable(var1, i);
               offspring2.setVariable(var2, i);
            }
        }
        Solution[] result = {offspring1, offspring2};
        return result;
    }

    public Solution mutationOperator(Solution solution) {
        int index = PseudoRandom.randInt(0, solution.getNumberOfDecisionVariables() - 1);
        int number = solution.getVariable(index);
        if (solution.getLowerBound(index) == solution.getUpperBound(index)) {
            number = solution.getLowerBound(index);
        } else {
            while (number == solution.getVariable(index)) {
                number = PseudoRandom.randInt(solution.getLowerBound(index), solution.getUpperBound(index));
            }
        }
        solution.setVariable(number, index);
        return solution;
    }
  
     public SolutionSet getbestSolution() {
       return result;
    }
     class SolutionComparator implements Comparator<Solution> {

        @Override
        public int compare(Solution s1, Solution s2) {
            if (s1.getFitness() == s2.getFitness()) {
                return 0;
            } else if (s1.getFitness() < s2.getFitness()) {
                return 1;
            } else {
                return -1;
            }
        }
    } 
     public int getLowerFE() {
        return LFE;
    }
      public Solution getUpperrSolution() {
        return UpperrSolution;
    }
    // public Solution getUpperSolution() {
    //    return UpperSolution;
    //}
     public int getUpperFE() {
        return UFE;
    }
    
}
